# PAXLOAD — Android source project

এই ZIP-এ PAXLOAD-এর উন্নত starter implementation আছে।

## Build
GitHub repository-র root-এ ZIP extract করে সব ফাইল upload করুন। `.github/workflows/build-paxload-apk.yml` অবশ্যই `.github/workflows/`-এ থাকবে। GitHub Actions থেকে **Build PAXLOAD APK** চালান।

## এই build-এ বাস্তবভাবে যা আছে
- Premium dark / electric-blue Compose UI
- Bangla / English toggle (local preference)
- Clipboard paste এবং Android share-intent থেকে link গ্রহণ
- HTTP/HTTPS URL-এর HEAD metadata inspection
- Direct media URL-এ Android DownloadManager enqueue
- Notification progress (Android DownloadManager-এর মাধ্যমে)
- Basic download history/status/size এবং cancel
- Downloads/PAXLOAD folder-এ save

## এখনো নেই / সীমাবদ্ধতা
- Facebook/Instagram/TikTok/YouTube page URL extraction নেই।
- Adaptive HLS/DASH stream parsing বা quality variant selector নেই।
- 16K selector নেই; source/API metadata ছাড়া quality বা size বানিয়ে দেখানো হয় না।
- Pause/resume, download speed meter, retry queue, in-app media playback/library এবং storage dashboard এখনো পূর্ণ implement করা হয়নি।
- Platform extraction কেবল সংশ্লিষ্ট প্ল্যাটফর্মের অনুমোদিত API/connector ও তাদের নীতিমালা অনুযায়ী আলাদা integration হিসেবে যোগ করতে হবে।
- DRM, private/paid বা access-controlled content bypass করা হয় না।

## Important
এটি source project, APK নয়। GitHub Actions-এ build না হওয়া পর্যন্ত compiled APK হয়েছে বলা যাবে না। Android/Gradle toolchain-এর পরিবর্তনে build error হলে Actions log দেখে fix করতে হবে।
