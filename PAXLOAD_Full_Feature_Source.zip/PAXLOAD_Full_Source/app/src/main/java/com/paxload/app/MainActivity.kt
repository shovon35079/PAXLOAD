package com.paxload.app

import android.app.DownloadManager
import android.app.Activity
import android.content.ContextWrapper
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.database.Cursor
import android.content.ContentValues
import android.provider.MediaStore
import java.net.HttpURLConnection
import java.net.URL
import java.text.DecimalFormat
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF122238)
private val Blue = Color(0xFF159BFF)
private val Muted = Color(0xFF9FB2CC)
private val Gold = Color(0xFFFFC078)

data class DownloadItem(val id: Long, val name: String, val status: String, val downloaded: Long, val total: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PaxloadApp() }
    }
}

@Composable
fun PaxloadApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("paxload", Context.MODE_PRIVATE) }
    var bangla by remember { mutableStateOf(prefs.getBoolean("bn", false)) }
    var urlText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var checking by remember { mutableStateOf(false) }
    var fileName by remember { mutableStateOf("") }
    var fileSize by remember { mutableStateOf(-1L) }
    var mime by remember { mutableStateOf("") }
    var items by remember { mutableStateOf(loadDownloads(context)) }
    var refresh by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val tr: (String, String) -> String = { en, bn -> if (bangla) bn else en }

    LaunchedEffect(Unit) {
        val shared = intentText(context)
        if (shared.isNotBlank()) urlText = shared
        else if (clipboard.hasPrimaryClip()) {
            val clip = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
            if (clip.startsWith("http")) urlText = clip
        }
    }
    LaunchedEffect(refresh) {
        items = loadDownloads(context)
    }
    LaunchedEffect(Unit) {
        while (true) {
            items = loadDownloads(context)
            delay(1000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Navy).padding(horizontal = 20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CloudDownload, null, tint = Blue, modifier = Modifier.size(42.dp))
                Spacer(Modifier.width(10.dp))
                Text("PAXLOAD", color = Blue, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    bangla = !bangla
                    prefs.edit().putBoolean("bn", bangla).apply()
                }) { Icon(Icons.Default.Language, null, tint = Blue); Text(if (bangla) "BN" else "EN", color = Blue) }
            }
            Text("PASTE  •  FETCH  •  DOWNLOAD", color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(24.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text(tr("Paste media link", "মিডিয়া লিংক পেস্ট করুন"), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = urlText, onValueChange = { urlText = it; message = "" },
                        modifier = Modifier.fillMaxWidth(), singleLine = false,
                        placeholder = { Text("https://...") },
                        leadingIcon = { Icon(Icons.Default.Link, null) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue, unfocusedBorderColor = Muted,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = {
                            val clip = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                            if (clip.isNotBlank()) urlText = clip else message = tr("Clipboard is empty", "ক্লিপবোর্ড খালি")
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.ContentPaste, null); Text(tr("Paste", "পেস্ট"))
                        }
                        Button(onClick = {
                            if (!urlText.trim().startsWith("https://") && !urlText.trim().startsWith("http://")) {
                                message = tr("Enter a valid http/https link.", "সঠিক http/https লিংক দিন।")
                            } else {
                                checking = true; message = ""
                                scope.launch {
                                    val result = inspectUrl(urlText.trim())
                                    checking = false
                                    fileName = result.first
                                    fileSize = result.second
                                    mime = result.third
                                    message = if (mime.startsWith("video/") || mime.startsWith("audio/") || mime == "application/octet-stream") {
                                        tr("Direct media file detected. Ready to download.", "সরাসরি মিডিয়া ফাইল পাওয়া গেছে। ডাউনলোডের জন্য প্রস্তুত।")
                                    } else {
                                        tr("This is not a confirmed direct media file. Platform page extraction is not enabled in this build.", "এটি সরাসরি মিডিয়া ফাইল নয়। এই সংস্করণে প্ল্যাটফর্ম পেজ থেকে ভিডিও বের করার সুবিধা নেই।")
                                    }
                                }
                            }
                        }, modifier = Modifier.weight(1f), enabled = !checking) {
                            if (checking) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Text(tr("Fetch Link", "লিংক যাচাই"))
                        }
                    }
                    if (fileName.isNotBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Text(fileName, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Type: $mime   •   Size: ${if (fileSize >= 0) human(fileSize) else "Unknown"}", color = Muted, fontSize = 12.sp)
                        Text(tr("Quality options are shown only when the source/API provides them.", "সোর্স/API দিলে তবেই Quality অপশন দেখানো যাবে।"), color = Muted, fontSize = 12.sp)
                        if (mime.startsWith("video/") || mime.startsWith("audio/") || mime == "application/octet-stream") {
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = {
                                try {
                                    val req = DownloadManager.Request(Uri.parse(urlText.trim()))
                                        .setTitle(fileName)
                                        .setDescription("PAXLOAD download")
                                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "PAXLOAD/$fileName")
                                        .setAllowedOverMetered(true)
                                        .setAllowedOverRoaming(false)
                                    val id = dm.enqueue(req)
                                    val p = context.getSharedPreferences("paxload", Context.MODE_PRIVATE)
                                    val ids = p.getStringSet("ids", emptySet())!!.toMutableSet()
                                    ids.add(id.toString()); p.edit().putStringSet("ids", ids).apply()
                                    refresh++
                                    message = tr("Download queued. Check notification and history.", "ডাউনলোড Queue-তে যোগ হয়েছে। Notification ও History দেখুন।")
                                } catch (e: Exception) {
                                    message = e.message ?: "Download could not start"
                                }
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Download, null); Text(tr("Download Now", "এখনই ডাউনলোড"))
                            }
                        }
                    }
                    if (message.isNotBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Text(message, color = if (message.contains("not", true) || message.contains("নয়")) Gold else Muted)
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, null, tint = Blue)
                Spacer(Modifier.width(8.dp))
                Text(tr("Download Manager", "ডাউনলোড ম্যানেজার"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, null, tint = Blue) }
            }
            if (items.isEmpty()) {
                Text(tr("No downloads yet", "এখনো কোনো ডাউনলোড নেই"), color = Muted, modifier = Modifier.padding(top = 16.dp))
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items) { item ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(item.name, fontWeight = FontWeight.SemiBold)
                                Text("${item.status} • ${human(item.downloaded)} / ${if (item.total > 0) human(item.total) else "?"}", color = Muted, fontSize = 12.sp)
                                if (item.total > 0) LinearProgressIndicator(
                                    progress = { (item.downloaded.toFloat() / item.total).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                    color = Blue
                                )
                                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                    TextButton(onClick = {
                                        dm.remove(item.id); refresh++
                                    }) { Text(tr("Cancel", "বাতিল"), color = Gold) }
                                }
                            }
                        }
                    }
                }
            }
            Text(tr("Supports direct media URLs in this release. Social-platform links require official/authorized integrations. No DRM, private or restricted-content bypass.", "এই সংস্করণে সরাসরি মিডিয়া URL সমর্থিত। সামাজিক প্ল্যাটফর্মের লিংকের জন্য অনুমোদিত Integration প্রয়োজন। DRM/Private/Restricted কনটেন্টের সুরক্ষা ভাঙা হয় না।"),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 14.dp))
        }
    }
}

private fun intentText(context: Context): String {
    var current: Context? = context
    while (current is ContextWrapper) {
        if (current is Activity) {
            val i = current.intent
            return if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
        }
        current = current.baseContext
    }
    return ""
}

private suspend fun inspectUrl(link: String): Triple<String, Long, String> = withContext(Dispatchers.IO) {
    try {
        val conn = (URL(link).openConnection() as HttpURLConnection).apply {
            requestMethod = "HEAD"; connectTimeout = 10000; readTimeout = 10000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "PAXLOAD Android")
        }
        conn.connect()
        val type = conn.contentType?.substringBefore(";") ?: ""
        val size = conn.contentLengthLong
        val disposition = conn.getHeaderField("Content-Disposition")
        val name = disposition?.substringAfter("filename=", "")?.trim('"')
            ?.takeIf { it.isNotBlank() } ?: URLUtil.guessFileName(link, disposition, type)
        conn.disconnect()
        Triple(name.ifBlank { "PAXLOAD_download" }, size, type)
    } catch (_: Exception) {
        Triple("PAXLOAD_download", -1L, "")
    }
}

private fun loadDownloads(context: Context): List<DownloadItem> {
    val prefs = context.getSharedPreferences("paxload", Context.MODE_PRIVATE)
    val ids = prefs.getStringSet("ids", emptySet()) ?: emptySet()
    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    return ids.mapNotNull { raw ->
        val id = raw.toLongOrNull() ?: return@mapNotNull null
        val c: Cursor? = dm.query(DownloadManager.Query().setFilterById(id))
        c?.use {
            if (!it.moveToFirst()) return@mapNotNull null
            val title = it.getString(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Download"
            val statusCode = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val status = when(statusCode) {
                DownloadManager.STATUS_PENDING -> "Queued"
                DownloadManager.STATUS_RUNNING -> "Downloading"
                DownloadManager.STATUS_PAUSED -> "Paused by system"
                DownloadManager.STATUS_SUCCESSFUL -> "Completed"
                DownloadManager.STATUS_FAILED -> "Failed"
                else -> "Unknown"
            }
            val done = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            DownloadItem(id, title, status, done, total)
        }
    }.reversed()
}

private fun human(bytes: Long): String {
    if (bytes < 0) return "Unknown"
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "${DecimalFormat("0.0").format(kb)} KB"
    val mb = kb / 1024
    if (mb < 1024) return "${DecimalFormat("0.0").format(mb)} MB"
    return "${DecimalFormat("0.00").format(mb / 1024)} GB"
}
