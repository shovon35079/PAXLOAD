# PAXLOAD Android Starter Project

**Brand:** PAXLOAD  
**Tagline:** Paste • Fetch • Download  
**Theme:** Black + Electric Blue  
**Languages:** বাংলা + English

## এই সংস্করণে যা কাজ করে
- বাংলা/English UI toggle
- Clipboard থেকে link paste
- HTTP/HTTPS direct media URL-এর HEAD metadata check
- Content type, filename ও file size দেখানো
- Android DownloadManager দিয়ে background download
- Android system notification-এ download progress
- অ্যাপের মধ্যে percentage ও downloaded/total size
- Download ID locally save করে history/progress পুনরায় দেখানো

## সীমাবদ্ধতা
এটি একটি **starter implementation**, universal social-platform extractor নয়। Facebook/Instagram/TikTok/YouTube ইত্যাদির সাধারণ page URL থেকে ভিডিও বের করতে আলাদা, অনুমোদিত platform connector/API প্রয়োজন। DRM, private, paid বা access-control bypass নেই। 16K quality কেবল তখনই সম্ভব যখন উৎসে সত্যিকারের 16K file/stream পাওয়া যায়। এই সংস্করণে direct file URL-এর original quality ডাউনলোড হয়; adaptive HLS/DASH quality picker ও platform connectors এখনো যোগ করা হয়নি।

## APK build (GitHub Actions)
1. ZIP extract করে GitHub repository-তে source upload করুন।
2. `.github/workflows/build-apk.yml` ফাইলটি repository-তে রাখুন।
3. GitHub → Actions → **Build PAXLOAD APK** → Run workflow.
4. সফল হলে `PAXLOAD-debug-apk` artifact থেকে `app-debug.apk` নামান।

## Local build
Android Studio / JDK 17 এবং Android SDK 35 দিয়ে `gradle assembleDebug` চালান।

## Package
`com.paxload.app`  
Version `1.0.0` (debug starter)
