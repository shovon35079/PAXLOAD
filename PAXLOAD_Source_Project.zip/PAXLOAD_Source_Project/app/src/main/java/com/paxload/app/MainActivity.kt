package com.paxload.app

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.DecimalFormat

private val Navy = Color(0xFF080F1D)
private val Panel = Color(0xFF111F33)
private val Blue = Color(0xFF159BFF)
private val Muted = Color(0xFF9EB4CE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PaxloadApp() }
    }
}

data class MediaInfo(val url: String, val name: String, val size: Long, val type: String)
data class DownloadRow(val id: Long, val name: String, val progress: Int, val status: String, val total: Long, val downloaded: Long)

@Composable
fun PaxloadApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("paxload", Context.MODE_PRIVATE) }
    var bangla by remember { mutableStateOf(prefs.getBoolean("bangla", false)) }
    var link by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<MediaInfo?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var downloads by remember { mutableStateOf(listOf<DownloadRow>()) }
    val dm = remember { context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }
    val title = if (bangla) "লিংক পেস্ট করুন" else "Paste video link"
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    LaunchedEffect(Unit) {
        while (true) {
            val rows = mutableListOf<DownloadRow>()
            val ids = prefs.getString("download_ids", "")!!.split(",").mapNotNull { it.toLongOrNull() }
            ids.forEach { id ->
                val c = dm.query(DownloadManager.Query().setFilterById(id))
                c?.use { if (it.moveToFirst()) {
                    val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)).coerceAtLeast(0)
                    val got = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)).coerceAtLeast(0)
                    val st = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    val p = if (total > 0) ((got * 100) / total).toInt().coerceIn(0,100) else 0
                    val label = when(st) { DownloadManager.STATUS_SUCCESSFUL -> if (bangla) "সম্পন্ন" else "Complete"; DownloadManager.STATUS_FAILED -> "Failed ($reason)"; DownloadManager.STATUS_PAUSED -> if (bangla) "বিরতিতে" else "Paused"; else -> if (bangla) "ডাউনলোড হচ্ছে" else "Downloading" }
                    rows.add(DownloadRow(id, "Download #$id", p, label, total, got))
                } }
            }
            downloads = rows.reversed()
            delay(1000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel, onSurface = Color.White)) {
        Scaffold(containerColor = Navy) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 30.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudDownload, null, tint = Blue, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.width(8.dp)); Text("PAXLOAD", color = Blue, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        TextButton(onClick = { bangla = !bangla; prefs.edit().putBoolean("bangla", bangla).apply() }) {
                            Icon(Icons.Default.Language, null); Spacer(Modifier.width(4.dp)); Text(if (bangla) "বাংলা" else "EN")
                        }
                    }
                    Text(if (bangla) "পেস্ট • খুঁজুন • ডাউনলোড" else "PASTE • FETCH • DOWNLOAD", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            OutlinedTextField(value = link, onValueChange = { link = it; info = null; message = "" }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://...", color = Muted) }, leadingIcon = { Icon(Icons.Default.Link, null) }, singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    val clip: ClipData? = clipboard.primaryClip
                                    if (clip != null && clip.itemCount > 0) link = clip.getItemAt(0).coerceToText(context).toString()
                                }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(5.dp)); Text(if (bangla) "পেস্ট" else "Paste") }
                                Button(onClick = {
                                    scope.launch {
                                        busy = true; info = null; message = ""
                                        val result = inspectDirectMedia(link)
                                        info = result.first; message = result.second; busy = false
                                    }
                                }, enabled = link.isNotBlank() && !busy, modifier = Modifier.weight(1f)) { Text(if (busy) "..." else if (bangla) "লিংক যাচাই" else "Fetch Link") }
                            }
                            if (message.isNotBlank()) Text(message, color = if (info != null) Color(0xFF70D6A2) else Color(0xFFFFC078), fontSize = 12.sp)
                        }
                    }
                }
                info?.let { media ->
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(if (bangla) "ডাউনলোড তথ্য" else "Download details", fontWeight = FontWeight.Bold)
                                Text(media.name, color = Color.White)
                                Text("${media.type}  •  ${formatSize(media.size)}", color = Muted, fontSize = 13.sp)
                                Text(if (bangla) "উৎসের মূল কোয়ালিটি" else "Original source quality", color = Blue, fontWeight = FontWeight.SemiBold)
                                Text(if (bangla) "এই সরাসরি ফাইলে আলাদা 360p–16K স্ট্রিম পাওয়া যায়নি। সোর্সে যতটুকু আছে সেটিই ডাউনলোড হবে।" else "No separate 360p–16K variants were exposed by this direct file URL. The source file will be downloaded as-is.", color = Muted, fontSize = 12.sp)
                                Button(onClick = {
                                    try {
                                        val req = DownloadManager.Request(Uri.parse(media.url)).setTitle(media.name).setDescription("PAXLOAD • ${formatSize(media.size)}").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "PAXLOAD/${safeName(media.name)}").setAllowedOverMetered(true).setAllowedOverRoaming(false)
                                        val id = dm.enqueue(req)
                                        val old = prefs.getString("download_ids", "")!!
                                        prefs.edit().putString("download_ids", (old + ",$id").trim(',' )).apply()
                                        message = if (bangla) "ডাউনলোড শুরু হয়েছে" else "Download started"
                                    } catch (e: Exception) { message = e.message ?: "Download could not start" }
                                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text(if (bangla) "ডাউনলোড শুরু করুন" else "Start Download") }
                            }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.History, tint = Blue, contentDescription = null); Spacer(Modifier.width(8.dp)); Text(if (bangla) "ব্যাকগ্রাউন্ড ডাউনলোড" else "Background downloads", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                }
                if (downloads.isEmpty()) item { Text(if (bangla) "এখনো কোনো ডাউনলোড নেই" else "No downloads yet", color = Muted, fontSize = 13.sp) }
                items(downloads) { d ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(d.name, fontWeight = FontWeight.SemiBold); Text("${d.progress}%", color = Blue, fontWeight = FontWeight.Bold) }
                            LinearProgressIndicator(progress = { d.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Blue, trackColor = Color(0xFF263B54))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(d.status, color = Muted, fontSize = 11.sp); Text("${formatSize(d.downloaded)} / ${formatSize(d.total)}", color = Muted, fontSize = 11.sp) }
                        }
                    }
                }
                item {
                    Text(if (bangla) "নোট: বর্তমানে সরাসরি ভিডিও/মিডিয়া ফাইল URL সমর্থিত। DRM, পেইড বা প্রাইভেট কনটেন্ট এবং প্ল্যাটফর্ম-নিষিদ্ধ ডাউনলোড সমর্থিত নয়। সোশ্যাল প্ল্যাটফর্মের লিংক থেকে ডাউনলোডের জন্য অনুমোদিত Connector/API আলাদাভাবে যুক্ত করতে হবে।" else "Note: This starter supports direct media-file URLs. DRM, paid, private or platform-restricted downloads are not supported. Social-platform extraction requires approved platform connectors/APIs.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

private suspend fun inspectDirectMedia(raw: String): Pair<MediaInfo?, String> = withContext(Dispatchers.IO) {
    try {
        val u = URL(raw.trim())
        require(u.protocol == "https" || u.protocol == "http") { "Only HTTP/HTTPS links are supported" }
        val c = (u.openConnection() as HttpURLConnection).apply { requestMethod = "HEAD"; connectTimeout = 12000; readTimeout = 12000; instanceFollowRedirects = true; setRequestProperty("User-Agent", "PAXLOAD-Android/1.0") }
        c.connect()
        val type = c.contentType ?: "application/octet-stream"
        val size = c.contentLengthLong.coerceAtLeast(0)
        val disposition = c.getHeaderField("Content-Disposition") ?: ""
        val fromHeader = Regex("filename\\*=UTF-8''([^;]+)|filename=\\\"?([^;\\\"]+)", RegexOption.IGNORE_CASE).find(disposition)
        val name = fromHeader?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() } ?: u.path.substringAfterLast('/').ifBlank { "paxload_download" }
        c.disconnect()
        if (!(type.startsWith("video/") || type.startsWith("audio/") || type == "application/octet-stream" || name.contains('.'))) return@withContext null to "This link did not identify itself as a direct media file."
        MediaInfo(raw.trim(), name, size, type) to "Direct media link detected."
    } catch (e: Exception) { null to (e.message ?: "Could not inspect this link. Try a direct media-file URL.") }
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "Size unknown"
    val mb = bytes / 1024.0 / 1024.0
    return if (mb >= 1024) "${DecimalFormat("0.00").format(mb / 1024)} GB" else "${DecimalFormat("0.0").format(mb)} MB"
}
private fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "download.bin" }
